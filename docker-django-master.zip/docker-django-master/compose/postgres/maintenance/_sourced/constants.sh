#!/usr/bin/env bash


BACKUP_DIR_PATH='/backups'
BACKUP_FILE_PREFIX='backup'
